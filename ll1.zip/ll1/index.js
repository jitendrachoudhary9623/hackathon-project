var express = require('express');
const fetch = require('node-fetch');
const request = require('request-promise');

var bodyParser = require('body-parser');
var app = express();

app.use(bodyParser.json());
const client_id = '9yMgYpxgmFdRGbt724uIGnCkrNpKLzhW';
const secret_key="bEc0HN24NGI5pYVG";
const redirect_uri = "https://a21fc42c.ngrok.io";
const subscription_id = 'test';
let token;

const API_CONFIG = {
    "apikey": client_id,
    "apisecret": secret_key,
    "Subscription-Id": "test"
}

const HEADERS = {
    "Accept": "*/*",
    "Content-Type": "application/json",
    "Authorization": "Basic " +
        Buffer.from(API_CONFIG.apikey + ':' + API_CONFIG.apisecret).toString('base64'),
    "Subscription-Id": API_CONFIG["Subscription-Id"]
}


//change request id
const HEADERS_WITH_REQUEST_ID = {
    "Accept": "*/*",
    "Content-Type": "application/json",
    "Request-Id":"Guid",
    "Prefer":"return=representation",
    "Authorization": "Basic " +
        Buffer.from(API_CONFIG.apikey + ':' + API_CONFIG.apisecret).toString('base64'),
    "Subscription-Id": API_CONFIG["Subscription-Id"]
}

let dialogFlow={
    "fulfillmentText": "Advisor",
    "fulfillmentMessages": [
      {
        "text": 
        {"text":[
            ""
          ]
      },
      }
    ],
    "source": "",
    "payload": {
        "google": {
          "expectUserResponse": true,
          "richResponse": {
            "items": [
              {
                "simpleResponse": {
                  "textToSpeech":""
                }
              }
            ]
          }
        }
    }
}

//queryBookingTime
app.get('/queryBookingTime', function(req, res){
  
   let options = {
    method: 'POST',
    url: 'https://api.fortellis.io/service/v1/scheduling/slots',
    headers: HEADERS_WITH_REQUEST_ID,
    body:{
        "startDateTime": "2018-10-10T07:09:53+08:00",
        "endDateTime": "2018-10-15T07:09:53+08:00",
        "vehicleInfo": {
            "spec": {
                "makeCode": "CHEV",
                "modelCode": "CAMAC",
                "modelYear": 2001
            }
        },
        "requestedServices": [
            {
                "sourceHref": "api.fortellis.io/service/reference/v4/service-packages/model/CHEV-CAMAC-2001-US/specifications/8994972"
            }
        ],
        "transportId": "123",
        "advisorId": "123"
    },
    json: true
}; 
request.post(options,function(err, resp, body) {
    if (err) {
       res.send({"error":body});
    } else {
       // var data=JSON.parse(body);
       items=body.items;
        res.send(items);
    }
});
});


//Reserve Appointment

app.get('/reserve', function(req, res){  
     let options = {
      method: 'POST',
      url: 'https://api.fortellis.io/cdkdrive/service/v1/repair-orders/',
      headers: HEADERS_WITH_REQUEST_ID,
     body:{
        "appointmentId": "8888",
        "blockIVRFlag": false,
        "comments": "Use synthetic 5W-20 engine oil",
        "customerHref": "https://api.fortellis.io/cdkdrive/crm/v1/customers/800245",
        "vehicleHref": "https://api.fortellis.io/cdkdrive/service/vehicles/4G263088",
        "customerContactInfo": "8302852330",
        "dropOff": {
            "dateTime": "2018-08-12T20:13:45",
            "address": "678 Montgomery St",
            "city": "Jersey City",
            "note": "Call before pickup",
            "phone": "8302852330",
            "vanNumber": "8302852330"
        },
        "estimate": {
            "authorized": 200,
            "labor": 80,
            "parts": 40,
            "misc": 30,
            "lube": 30,
            "sublet": 10,
            "tax": 10
        },
        "mileageIn": {
            "value": 87665,
            "units": "KM"
        },
        "pickUp": {
            "dateTime": "2018-08-12T20:19:45",
            "address": "678 Montgomery St",
            "city": "Jersey City",
            "note": "Call before pickup",
            "phone": "8302852330",
            "vanNumber": "8302852330"
        },
        "promiseDateTime": "2018-08-12T20:17:45",
        "serviceAdvisorId": "6164",
        "tagNum": "3088",
        "remarks": "sample remarks",
        "transportType": "DROPOFF",
        "serviceLineItems": [
            {
                "cause": "Braking issue",
                "comebackFlag": false,
                "dispatchCode": "S104",
                "estimatedDuration": 1.5,
                "laborEstimate": 10,
                "laborType": "CEC",
                "lubeEstimate": 10,
                "miscEstimate": 10,
                "partsEstimate": 10,
                "serviceEstimate": 10,
                "status": {
                    "code": "I93",
                    "description": "PREASSIGNED"
                },
                "serviceRequest": "CUSTOMER STATES THERE IS A CLUNKING SOUND IN FRONT END OVER BUMPS",
                "subletEstimate": 10,
                "taxEstimate": 10,
                "technicianId": "253",
                "laborOperations": [
                    {
                        "forceShopChargeFlag": false,
                        "laborType": "CEC",
                        "opCode": "SSTR",
                        "opCodeDesc": "SUSPENSION AND STEERING REPAIR",
                        "soldHours": 0.2,
                        "saleAmount": 7,
                        "saleOverrideFlag": false,
                        "includedParts": [
                            {
                                "fixedSaleFlag": false,
                                "includesCoreFlag": false,
                                "mfrCode": "FR",
                                "partNumber": "P9488",
                                "partNumberDescription": "CLUTCH PLATE",
                                "partQty": 1,
                                "saleAmount": 30
                            },
                            {
                                "fixedSaleFlag": false,
                                "includesCoreFlag": false,
                                "mfrCode": "FR",
                                "partNumber": "7488",
                                "partNumberDescription": "BRAKEPAD",
                                "partQty": 2,
                                "saleAmount": 50
                            }
                        ]
                    }
                ]
            }
        ]
    },
      json: true
  }; 
  request.post(options,function(err, resp, body) {
      if (err) {
         res.send({"error":err});
      } else {
         // var data=JSON.parse(body);
         
          res.send(body);
      }
  });
  });






app.get('teams/', function(req, res){
    console.log( "Basic " +
    Buffer.from(API_CONFIG.apikey + ':' + API_CONFIG.apisecret).toString('base64'));
    let options = {
        method: 'GET',
        url:'https://api.fortellis.io/service/v1/scheduling/lookups/teams',
        headers: HEADERS
    };

    request.get(options,function(err, resp, body) {
        if (err) {
           res.send({"error":JSON.parse(err)});
        } else {
            res.send(JSON.parse(body));
        }
    });
    
});

app.get('teams/:teamId/', function(req, res){
    var id = req.params.teamId;
    console.log( "Basic " +
    Buffer.from(API_CONFIG.apikey + ':' + API_CONFIG.apisecret).toString('base64'));
    let options = {
        method: 'GET',
        url:'https://api.fortellis.io/service/v1/scheduling/lookups/team/'+id,
        headers: HEADERS
    };

    request.get(options,function(err, resp, body) {
        if (err) {
           res.send({"error":JSON.parse(err)});
        } else {
            res.send(JSON.parse(body));
        }
    });
    
});

app.post('/webhook',function(req,res){

    let options;
    let response;
    var action;
    console.log(req.body);
    if(req.body.queryResult.parameters.any==Object){
        action=JSON.stringify(req.body.queryResult.intent.displayName);
    }
    else{
        action=req.body.queryResult.intent.displayName;
    }
    console.log("Action is "+action+" "+typeof(action)+" "+String(action));
    switch(String(action)){
        case "Advisor":
                 options = {
                    method: 'GET',
                    url: 'https://api.fortellis.io/service/v1/scheduling/lookups/advisors',
                    headers: HEADERS
                };
               console.log("Advisors recieved")
                request.get(options,function(err, resp, body) {
                    if (err) {
                       return {"error":JSON.parse(err)};
                    } else {
                        console.log("recieved");
                        var data=JSON.parse(body);

                        var items=data["items"];
                        var output="We have ";
                        for(var i=0;i<items.length;i++){
                            output=output+`${items[i].advisorName} from team ${items[i].teamName} with advisor id ${items[i].advisorId} `;
                        }
                        output=output+" You can get more details regarding them by their ids";
                        let response={
                            "fulfillmentText": "Advisor",
                            "fulfillmentMessages": [
                              {
                                "text": 
                                {"text":[
                                    output
                                  ]
                              },
                              }
                            ],
                            "source": "",
                            "payload": {
                                "google": {
                                  "expectUserResponse": true,
                                  "richResponse": {
                                    "items": [
                                      {
                                        "simpleResponse": {
                                          "textToSpeech":output
                                        }
                                      }
                                    ]
                                  }
                                }
                            }
                        }
                        console.log(response);
                        res.send(response);
                    }
                });
        break;
        case "GetTransportID":
                 options = {
                    method: 'GET',
                    url: 'https://api.fortellis.io/service/v1/scheduling/lookups/transports',
                    headers: HEADERS
                };
                request.get(options,function(err, resp, body) {
                    if (err) {
                       res.send({"error":JSON.parse(err)});
                    } else {
                        var data=JSON.parse(body);
                        response={
                            "fulfillmentText": "transport",
                            "fulfillmentMessages": [
                              {
                                "text": 
                                {"text":[
                                    `We have ${data.items[0].name} facility which is as follows. ${data.items[0].description}`,data.items[0].description,"We have various transport options"
                                  ]
                              },
                              }
                            ],
                            "source": "",
                            "payload": {
                                "google": {
                                  "expectUserResponse": true,
                                  "richResponse": {
                                    "items": [
                                      {
                                        "simpleResponse": {
                                          "textToSpeech":`We have ${data.items[0].name} facility which is as follows. ${data.items[0].description}`
            
                                        }
                                      }
                                    ]
                                  }
                                }
                            }
                        }
            
                        res.send(response);
                    }
                });
            break;
        case "GetAvailableSlots":
                var startDateTime="2018-10-15T07:09:53+08:00";
            if(req.body.queryResult.parameters){
                if(req.body.queryResult.parameters.date){
                 startDateTime=req.body.queryResult.parameters.date;
                }
            }
              
                options = {
                    method: 'POST',
                    url: 'https://api.fortellis.io/service/v1/scheduling/slots',
                    headers: HEADERS_WITH_REQUEST_ID,
                    body:{
                        "startDateTime": startDateTime,
                        "endDateTime": "2018-10-15T07:09:53+08:00",
                        "vehicleInfo": {
                            "spec": {
                                "makeCode": "CHEV",
                                "modelCode": "CAMAC",
                                "modelYear": 2001
                            }
                        },
                        "requestedServices": [
                            {
                                "sourceHref": "api.fortellis.io/service/reference/v4/service-packages/model/CHEV-CAMAC-2001-US/specifications/8994972"
                            }
                        ],
                        "transportId": "123",
                        "advisorId": "123"
                    },
                    json: true
                }; 
                request.post(options,function(err, resp, body) {
                    if (err) {
                       res.send({"error":body});
                    } else {
                       // var data=JSON.parse(body);
                       items=body.items;
                       output="Here is the list of available slots for booking \n";
                       for(var i=0;i<items.length;i++){
                        var dateobj = new Date(items[i].dateTime); 
                            output=output+dateobj.toString()+" \n";
                       }
                       response={
                        "fulfillmentText": "Advisor",
                        "fulfillmentMessages": [
                          {
                            "text": 
                            {"text":[
                                output
                              ]
                          },
                          }
                        ],
                        "source": "",
                        "payload": {
                            "google": {
                              "expectUserResponse": true,
                              "richResponse": {
                                "items": [
                                  {
                                    "simpleResponse": {
                                      "textToSpeech":output
                                    }
                                  }
                                ]
                              }
                            }
                        }
                    }
                    console.log(response);
                        res.send(response);
                    }
                });
                break;
        case "Reason for appointment":
                options = {
                    method: 'POST',
                    url: 'https://api.fortellis.io/service/v3/appointments/',
                    headers: HEADERS_WITH_REQUEST_ID,
                    body:
                    {
                        "dateTime": "2019-06-10T16:15:00+08:00",
                        "requestedServices": [
                            {
                                "description": "Filler, Tail Lamp Center - Replace (Labor Only)",
                                "sourceHref": "api.fortellis.io/service/reference/v4/service-packages/model/CHEV-CAMAC-2001-US/packages/BF018/specifications/8994972"
                            }
                        ],
                        "vehicleHref": "api.fortellis.io/service/v1/vehicles/123",
                        "vehicleMileage": {
                            "value": 34760,
                            "units": "MILES"
                        },
                        "customerHref": "api.fortellis.io/service/v1/customers/123",
                        "contact": {
                            "label": "mobile",
                            "uri": "tel:1-234-567-8900",
                            "preferences": [
                                {
                                    "startDay": "MON",
                                    "endDay": "FRI",
                                    "startTime": "1000",
                                    "endTime": "1600"
                                }
                            ]
                        },
                        "transportHref": "api.fortellis.io/service/v1/scheduling/lookups/transports/123",
                        "advisorHref": "api.fortellis.io/service/v1/scheduling/lookups/advisors/123",
                        "concerns": "My driver side front door rattles when I drive faster than 45",
                        "remarks": "Customer reports that driver side front door exhibits a rattle above 45mph"
                    },
                    json: true
                }; 
                request.post(options,function(err, resp, body) {
                    if (err) {
                       res.send({"error":body});
                    } else {
                    output=`Booking successfull, Your booking id is ${body.appointmentId} , add have added remarks as ${body.remarks}`
                       response={
                        "fulfillmentText": "Advisor",
                        "fulfillmentMessages": [
                          {
                            "text": 
                            {"text":[
                                output
                              ]
                          },
                          }
                        ],
                        "source": "",
                        "payload": {
                            "google": {
                              "expectUserResponse": true,
                              "richResponse": {
                                "items": [
                                  {
                                    "simpleResponse": {
                                      "textToSpeech":output
                                    }
                                  }
                                ]
                              }
                            }
                        }
                    }
                    console.log(response);
                        res.send(response);
                    }
                });
            break; 
        case "DeleteAppointment":
                options = {
                    method: 'DELETE',
                    url: 'https://api.fortellis.io/service/v3/appointments/123',
                    headers: HEADERS_WITH_REQUEST_ID,
                    body:
                    {
                        "reason": "Rescheduled for the following week"
                    },
                    json: true
                }; 
                request.delete(options,function(err, resp, body) {
                    if (err) {
                       res.send({"error":body});
                    } else {
                    output="Your appointment with id 123 is cancelled, Thank you"
                       response={
                        "fulfillmentText": "Advisor",
                        "fulfillmentMessages": [
                          {
                            "text": 
                            {"text":[
                                output
                              ]
                          },
                          }
                        ],
                        "source": "",
                        "payload": {
                            "google": {
                              "expectUserResponse": true,
                              "richResponse": {
                                "items": [
                                  {
                                    "simpleResponse": {
                                      "textToSpeech":output
                                    }
                                  }
                                ]
                              }
                            }
                        }
                    }
                    console.log(response);
                        res.send(response);
                    }
                });
        break;
        default:
                response={
                    "fulfillmentText": "Advisor",
                    "fulfillmentMessages": [
                      {
                        "text": 
                        {"text":[
                            "Something went wrong"
                          ]
                      },
                      }
                    ],
                    "source": "",
                    "payload": {
                        "google": {
                          "expectUserResponse": true,
                          "richResponse": {
                            "items": [
                              {
                                "simpleResponse": {
                                  "textToSpeech":"Something went wrong"
                                }
                              }
                            ]
                          }
                        }
                    }
                }
                console.log(response);
                res.send(response);
    }
    
});
app.listen(9876);